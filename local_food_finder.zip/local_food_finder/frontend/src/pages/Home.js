import { useEffect } from "react";
import "./../style/Home.css";
import {
  FaSearch,
  FaLeaf,
  FaMapMarkedAlt,
  FaQuoteLeft,
  FaShoppingBasket,
  FaHandsHelping,
  FaPlayCircle,
  FaChartLine,
  FaUsers,
} from "react-icons/fa";

const Home = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="home">
      {/* Hero Section */}
      <div className="hero">
        <div className="hero-overlay">
          <h1 className="hero-title">Fresh. Local. Sustainable.</h1>
          <p className="hero-subtitle">
            Discover the best local food from farmers near you.
          </p>
          <div className="search-box">
            <input type="text" className="search-input" placeholder="Search for local farmers, products..." />
            <button className="cta-btn">
              <FaSearch /> Find Fresh Food
            </button>
          </div>
        </div>
      </div>

      {/* Statistics Section */}
      <section className="statistics">
        <div className="stat-card"><FaUsers /><h3>10,000+ Users</h3><p>Active community members.</p></div>
        <div className="stat-card"><FaShoppingBasket /><h3>5,000+ Farmers</h3><p>Providing fresh, organic food.</p></div>
        <div className="stat-card"><FaChartLine /><h3>30% Growth</h3><p>In local farm sales this year.</p></div>
      </section>

      {/* Why Choose Us Section */}
      <section className="why-choose-us">
        <h2>Why Choose Us?</h2>
        <div className="features-grid">
          <div className="feature-card"><FaLeaf /><h3>Organic & Fresh</h3><p>We connect you with farmers offering the freshest produce.</p></div>
          <div className="feature-card"><FaMapMarkedAlt /><h3>Local & Sustainable</h3><p>Support local farms and sustainable agriculture.</p></div>
          <div className="feature-card"><FaShoppingBasket /><h3>Exclusive Deals</h3><p>Get access to special offers from local sellers.</p></div>
          <div className="feature-card"><FaHandsHelping /><h3>Community Support</h3><p>Strengthening local farmers and small businesses.</p></div>
        </div>
      </section>

      {/* Featured Farmers Section */}
      <section className="farmer-spotlight">
        <h2>Meet Our Featured Farmers</h2>
        <div className="farmer-grid">
          <div className="farmer-card">
            <img src="../assets/images/farmer1.jpg" alt="Farmer Jaga" />
            <h3>Jaga's Organic Farm</h3>
            <p>Growing fresh vegetables and fruits since 1998.</p>
          </div>
          <div className="farmer-card">
            <img src="../assets/images/farmer2.jpg" alt="Farmer Subrat" />
            <h3>Subrat's Greenhouse</h3>
            <p>Specializing in organic herbs and spices.</p>
          </div>
        </div>
      </section>

      {/* Video Section */}
      <section className="video-section">
        <h2>Explore Local Farms</h2>
        <div className="video-container">
          <a href="https://www.youtube.com/watch?v=abc123" target="_blank" rel="noopener noreferrer">
            <FaPlayCircle className="play-icon" />
          </a>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="testimonials">
        <h2>What Our Users Say</h2>
        <div className="testimonial-card">
          <FaQuoteLeft className="quote-icon" />
          <p>"This app helped me find amazing local produce. The quality is unbeatable!"</p>
          <h4>- Anil Bose.</h4>
        </div>
        <div className="testimonial-card">
          <FaQuoteLeft className="quote-icon" />
          <p>"I love supporting local farmers. Great service and fresh products!"</p>
          <h4>- Sonia S.</h4>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="cta-section">
        <h2>Join Our Community</h2>
        <p>Become a part of our growing network of farmers, food lovers, and sustainability enthusiasts.</p>
        <button className="cta-join-btn">Join Now</button>
      </section>
    </div>
  );
};

export default Home;
