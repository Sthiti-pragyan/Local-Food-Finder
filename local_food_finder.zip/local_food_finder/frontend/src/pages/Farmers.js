import { useState } from "react";
import FarmerCard from "../components/FarmerCard";
import "./../style/Farmers.css";
import {
   FaLeaf,  FaCamera, 
} from "react-icons/fa";

const farmersData = [
  {
    id: 1,
    name: "Jaga Pradhan",
    location: "Nuagaon, Nayagarh",
    specialty: "Organic Vegetables",
    experience: 12,
    farmSize: "50 acres",
    ecoRating: 5,
    event: "Sustainable Farming Workshop - April 15",
    weather: "🌤️ 20°C, Clear Sky",
    impactSaved: "You’ve saved 3.5kg of CO₂ this week!",
    video: "https://www.youtube.com/embed/xyz123",
    arTour: "/assets/ar-tour/jaga-farm",
    subscription: "Subscribe for weekly fresh produce updates",
    qrCode: "/assets/qrcode/johns-farm.png",
    liveCam: "https://farmcam.live/jaga",
    challenges: "Join the 'Eat Local for a Week' challenge and earn rewards!",
    auction: "Bid for fresh organic strawberries!",
    image: "/assets/images/farmer1.jpg"
  },
  {
    id: 2,
    name: "Manini Sahu",
    location: "Bari, Jajpur",
    specialty: "Dairy & Milk Products",
    experience: 8,
    farmSize: "120 acres",
    ecoRating: 4,
    event: "Organic Dairy Processing Tour - May 2",
    weather: "☁️ 18°C, Partly Cloudy",
    impactSaved: "You’ve saved 2.1kg of CO₂ this week!",
    video: "https://www.youtube.com/embed/abc456",
    arTour: "/assets/ar-tour/marys-dairy",
    subscription: "Manini Sahu's dairy club for premium organic milk!",
    qrCode: "/assets/qrcode/marys-dairy.png",
    liveCam: "https://farmcam.live/manini",
    challenges: "Try cooking with only seasonal ingredients!",
    auction: "Bid for farm-fresh cheese!",
    image: "/assets/images/farmer2.jpg"
  },
];

const Farmers = () => {
  const [search, setSearch] = useState("");

  const filteredFarmers = farmersData.filter(farmer =>
    farmer.name.toLowerCase().includes(search.toLowerCase()) ||
    farmer.specialty.toLowerCase().includes(search.toLowerCase()) ||
    farmer.location.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="farmers-page">
      {/* Hero Section */}
      <div className="farmers-hero">
        <h1>🌍 Explore Local Farmers</h1>
        <p>Support sustainable agriculture and connect with organic food producers.</p>
        <input 
          type="text" 
          className="search-bar" 
          placeholder="Search by name, location, or specialty..." 
          value={search} 
          onChange={(e) => setSearch(e.target.value)} 
        />
      </div>

      {/* AI Farm Matchmaking */}
      <section className="farm-match">
        <h2>🔍 AI-Powered Farm Recommendations</h2>
        <p>Find the best farmers based on your food preferences.</p>
        <button className="cta-btn">Get Matched</button>
      </section>

      {/* Featured Farmers */}
      <section className="farmers-list">
        <h2>🌱 Meet Our Farmers</h2>
        <div className="farmers-grid">
          {filteredFarmers.map(farmer => (
            <FarmerCard key={farmer.id} farmer={farmer} />
          ))}
        </div>
      </section>

      {/* Sustainable Impact Tracker */}
      <section className="impact-tracker">
        <h2>🌎 Your Sustainability Impact</h2>
        <p>Track how much CO₂ you’ve saved by eating locally.</p>
        <div className="impact-box">
          <FaLeaf /> <span>{farmersData[0].impactSaved}</span>
        </div>
      </section>

      {/* Farm Visit Planner & GPS */}
      <section className="farm-visit">
        <h2>📍 Plan Your Farm Visit</h2>
        <p>Find the best route and visiting hours.</p>
        <button className="map-btn">Get Directions</button>
      </section>

      {/* Blockchain-Based Transparency */}
      <section className="blockchain-tracker">
        <h2>🔗 Verify Farm Products</h2>
        <p>Scan QR codes to track the journey of your food.</p>
        <img src={farmersData[0].qrCode} alt="QR Code" className="qr-code" />
      </section>

      {/* Live Farm Cam */}
      <section className="live-farm-cam">
        <h2>🎥 Watch Farms in Real-Time</h2>
        <iframe src={farmersData[0].liveCam} className="live-video" />
      </section>

      {/* Gamification & Challenges */}
      <section className="farm-challenges">
        <h2>🏆 Take a Local Food Challenge</h2>
        <p>{farmersData[0].challenges}</p>
        <button className="challenge-btn">Join Now</button>
      </section>

      {/* AR Farm Experience */}
      <section className="ar-farm-tours">
        <h2>📸 Explore Farms in AR</h2>
        <div className="ar-grid">
          {filteredFarmers.map(farmer => (
            <a key={farmer.id} href={farmer.arTour} target="_blank" rel="noopener noreferrer">
              <FaCamera className="ar-icon" /> Virtual Tour of {farmer.name}'s Farm
            </a>
          ))}
        </div>
      </section>

      {/* Farm Product Bidding */}
      <section className="farm-bidding">
        <h2>💰 Bid for Fresh Produce</h2>
        <p>{farmersData[0].auction}</p>
        <button className="bid-btn">Place a Bid</button>
      </section>
    </div>
  );
};

export default Farmers;
