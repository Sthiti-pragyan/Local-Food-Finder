import React, { useState, useEffect } from "react";
import ProductCard from "../components/ProductCard";
import Filter from "../components/Filter";
import productService from "../services/productService";
import "./../style/ProductCard.css"; 

const Products = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedSeason, setSelectedSeason] = useState("All");

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await productService.getProducts();
        setProducts(data);
        setFilteredProducts(data);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };

    fetchProducts();
  }, []);

  const handleFilterChange = (category, season) => {
    setSelectedCategory(category);
    setSelectedSeason(season);

    let filtered = products;

    if (category !== "All") {
      filtered = filtered.filter((product) => product.category === category);
    }
    if (season !== "All") {
      filtered = filtered.filter((product) => product.season === season);
    }

    setFilteredProducts(filtered);
  };

  return (
    <div className="products-container">
      <h1>🌱 Local Seasonal Produce</h1>
      <p>Find fresh, locally sourced, and seasonal produce from nearby farmers.</p>

      {/* Filter Component */}
      <Filter 
        selectedCategory={selectedCategory} 
        selectedSeason={selectedSeason} 
        onFilterChange={handleFilterChange} 
      />

      {/* Product List */}
      <div className="product-list">
        {filteredProducts.length > 0 ? (
          filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))
        ) : (
          <p>No products found for the selected filters.</p>
        )}
      </div>

      {/* Why Choose Local Produce? */}
      <div className="why-local">
        <h2>🌎 Why Choose Local Produce?</h2>
        <ul>
          <li>🌿 **Fresher & Healthier** – Straight from the farm to your table.</li>
          <li>🚜 **Supports Local Farmers** – Helps small businesses grow.</li>
          <li>🌎 **Eco-Friendly** – Reduces transport emissions.</li>
          <li>🍽️ **Tastier & Seasonal** – Enjoy food at its peak freshness.</li>
        </ul>
      </div>

      {/* Featured Farmer */}
      <div className="featured-farmer">
        <h2>🌾 Featured Farmer of the Week</h2>
        <p><strong>John's Organic Farm</strong> – Growing fresh, pesticide-free vegetables for over 10 years.</p>
      </div>
    </div>
  );
};

export default Products;
