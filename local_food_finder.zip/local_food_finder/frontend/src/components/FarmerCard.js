import { Link } from "react-router-dom";
import { FaMapMarkerAlt, FaStar,  FaTractor } from "react-icons/fa";
import "./../style/Farmers.css";

const FarmerCard = ({ farmer }) => {
  return (
    <div className="farmer-card">
      <img src={farmer.image} alt={farmer.name} className="farmer-image" />
      <div className="farmer-info">
        <h3>{farmer.name}</h3>
        <p className="farmer-location"><FaMapMarkerAlt /> {farmer.location}</p>
        <p className="farmer-specialty">{farmer.specialty}</p>
        <p className="farmer-experience"><FaTractor /> {farmer.years} years of experience</p>
        <p className="farmer-farm-size">Farm Size: {farmer.farmSize}</p>
        <div className="rating">
          {[...Array(farmer.rating)].map((_, i) => <FaStar key={i} />)}
        </div>
        <Link to={`/farmers/${farmer.id}`} className="view-profile">View Profile</Link>
      </div>
    </div>
  );
};

export default FarmerCard;
