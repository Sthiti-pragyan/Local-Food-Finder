import React from "react";
import "./../style/ProductCard.css";

const ProductCard = ({ product }) => {
  if (!product) return null;

  const productDescriptions = {
    Carrot: "Crunchy and rich in vitamins, perfect for soups and salads.",
    Tomato: "Juicy and flavorful, great for sauces and fresh dishes.",
    Apple: "Sweet and crisp, a perfect healthy snack.",
    Strawberry: "Fresh and sweet, ideal for desserts and smoothies.",
    "Fresh Milk": "Locally sourced, fresh dairy for your daily needs.",
    "Organic Cheese": "Rich and creamy cheese made from organic milk.",
    Basil: "Aromatic and flavorful, perfect for Italian dishes.",
    Potatoes: "Versatile and filling, great for fries, mash, or roasts.",
    Blueberries: "Packed with antioxidants, a superfood for your health."
  };

  return (
    <div className="product-card">
      <h2>{product.name}</h2>
      <p><strong>Category:</strong> {product.category}</p>
      <p><strong>Season:</strong> {product.season}</p>
      <p>{productDescriptions[product.name]}</p>
    </div>
  );
};

export default ProductCard;
