import React from "react";

const Filter = ({ selectedCategory, selectedSeason, onFilterChange }) => {
  const categories = ["All", "Vegetables", "Fruits", "Dairy & Bakery", "Herbs & Spices"];
  const seasons = ["All", "Winter", "Spring", "Summer", "Fall"];

  return (
    <div className="filter-container">
      <label>Category:</label>
      <select value={selectedCategory} onChange={(e) => onFilterChange(e.target.value, selectedSeason)}>
        {categories.map((category) => (
          <option key={category} value={category}>{category}</option>
        ))}
      </select>

      <label>Season:</label>
      <select value={selectedSeason} onChange={(e) => onFilterChange(selectedCategory, e.target.value)}>
        {seasons.map((season) => (
          <option key={season} value={season}>{season}</option>
        ))}
      </select>
    </div>
  );
};

export default Filter;
