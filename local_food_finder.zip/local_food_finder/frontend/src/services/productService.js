const getProducts = async () => {
    return [
      { id: 1, name: "Carrot", category: "Vegetables", season: "Winter" },
      { id: 2, name: "Tomato", category: "Vegetables", season: "Summer" },
      { id: 3, name: "Apple", category: "Fruits", season: "Fall" },
      { id: 4, name: "Strawberry", category: "Fruits", season: "Spring" },
      { id: 5, name: "Fresh Milk", category: "Dairy & Bakery", season: "All" },
      { id: 6, name: "Organic Cheese", category: "Dairy & Bakery", season: "All" },
      { id: 7, name: "Basil", category: "Herbs & Spices", season: "Summer" },
      { id: 8, name: "Potatoes", category: "Vegetables", season: "Fall" },
      { id: 9, name: "Blueberries", category: "Fruits", season: "Summer" }
    ];
  };
  
  export default { getProducts };
  